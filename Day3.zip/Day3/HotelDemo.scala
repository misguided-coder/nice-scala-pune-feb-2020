object HotelDemo {

	def main(args: Array[String]):Unit = {
		Hotel.info
		println(Hotel.hashCode)
	}	
}

