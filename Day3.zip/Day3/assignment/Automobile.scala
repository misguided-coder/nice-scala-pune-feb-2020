trait Automobile {
	def start
	def stop
}
