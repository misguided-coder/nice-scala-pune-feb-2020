object HouseKeeper {
	
	def doClean(vehicle:Washable) {
		println("HouseKeeper is ready to clean!!!!")	
		vehicle.clean
	}
}
