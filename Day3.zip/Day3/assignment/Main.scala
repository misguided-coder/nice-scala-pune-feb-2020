object Main {

	def main(args: Array[String]):Unit = {

		var car = new Car
		var bus = new Bus
		var bike1 = new Bike with Logger
		var bike2 = new Bike with FineLogger
		var bike3 = new Bike
		
		car.log("Car is sold")
		bus.log("Bus is sold")
		bike1.log("Bike is sold")
		bike2.log("Bike is sold")
		
		/*var car = new Car
		var bus = new Bus
		var bike = new Bike
		var erikshaw = new Erikshaw
		
		Driver.doDrive(car)
		Driver.doDrive(bus)
		Driver.doDrive(bike)
		Driver.doDrive(erikshaw)

		Racer.doRace(car)
		Racer.doRace(bus)
		Racer.doRace(bus)

		Mechanic.doRepair(bike)
		Mechanic.doRepair(erikshaw)

		HouseKeeper.doClean(car)
		HouseKeeper.doClean(bike)*/
	}

}
