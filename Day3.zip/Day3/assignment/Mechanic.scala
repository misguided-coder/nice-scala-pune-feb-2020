object Mechanic {
	
	def doRepair(vehicle:Repairable) {
		println("Mechanic is ready to repair!!!!")	
		vehicle.repair
	}
}
