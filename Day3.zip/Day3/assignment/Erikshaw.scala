class Erikshaw extends Vehicle with Brakable with Repairable {
	def start() {
		println("Erikshaw engine is started with button press!!!!")		
	}


	def applyBrake() {
		this.speed = this.speed - 10
		println(s"Erikshaw is speeding down and running at $speed miles per hour!!!!")		
	}

	def repair() {
		println("Erikshaw has gone for repairing!!!!")		
	}
}
