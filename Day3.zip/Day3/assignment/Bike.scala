class Bike extends Vehicle with Acceleratable with Repairable with Washable {
	def start() {
		println("Bike engine is started with button press!!!!")		
	}

	def speedUp() {
		this.speed = this.speed + 10
		println(s"Bike is speeding up and running at $speed miles per hour!!!!")		
	}

	def repair() {
		println("Bike has gone for repairing!!!!")		
	}

	def clean() {
		println("Bike has gone for washing!!!!")		
	}
}
