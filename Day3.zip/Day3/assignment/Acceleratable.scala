trait Acceleratable {
	def speedUp
}
