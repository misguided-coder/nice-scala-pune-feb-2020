trait Repairable {
	def repair
}
