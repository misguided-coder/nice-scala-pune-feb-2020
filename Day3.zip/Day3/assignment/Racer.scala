object Racer {
	
	def doRace(vehicle:Acceleratable) {
		println("Racer is ready to race!!!!")	
		vehicle.speedUp
		vehicle.speedUp
		vehicle.speedUp
		vehicle.speedUp
	}
}
