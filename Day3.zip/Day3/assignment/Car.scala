class Car extends Vehicle with Acceleratable with Brakable with Washable with FineLogger with Logger {
	
	override def log(message:String) {
		super.log(message)
	}
	
	def start() {
		log("Car engine is started with button press!!!!")		
	}

	def speedUp() {
		this.speed = this.speed + 10
		println(s"Car is speeding up and running at $speed miles per hour!!!!")		
	}

	def applyBrake() {
		this.speed = this.speed - 10
		println(s"Car is speeding down and running at $speed miles per hour!!!!")		
	}

	def clean() {
		println("Car has gone for washing!!!!")		
	}
}
