trait Washable {
	def clean
}
