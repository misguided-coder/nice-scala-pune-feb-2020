trait FineLogger {

	import java.time.LocalDateTime
	
	def log(message:String) {
		println(s"INFO ${LocalDateTime.now()}----- $message")
	}
}
