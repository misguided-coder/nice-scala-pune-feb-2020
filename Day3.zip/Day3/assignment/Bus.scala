class Bus extends Vehicle with Acceleratable with Brakable with Logger {
	def start() {
		log("Bus engine is started with key!!!!")		
	}

	def speedUp() {
		this.speed = this.speed + 10
		println(s"Bus is speeding up and running at $speed miles per hour!!!!")		
	}

	def applyBrake() {
		this.speed = this.speed - 10
		println(s"Bus is speeding down and running at $speed miles per hour!!!!")		
	}

}
