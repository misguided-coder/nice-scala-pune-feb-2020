object Driver {
	
	def doDrive(vehicle:Vehicle) {
		println("Driver is ready to drive!!!!")	
		vehicle.start
		vehicle.stop
	}
}
