trait Brakable {
	def applyBrake
}
