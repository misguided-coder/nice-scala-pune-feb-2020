abstract class Vehicle extends Automobile {

	var speed:Int = 100

	def stop() {
		println("Vehicle engine is stopped!!!!")		
	}
}
