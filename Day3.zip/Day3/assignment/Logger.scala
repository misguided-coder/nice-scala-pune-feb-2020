trait Logger {

	def log(message:String) {
		println(s"INFO ----- $message")
	}
}
