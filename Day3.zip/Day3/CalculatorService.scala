/*
API - This calculator API is designed generic way to support 
      simple calculations
Developer - Ritesh Tyagi
Date - 12-Mar-2014
Version - 1.0.0
*/
object CalculatorService {


	def calculate(arg1:Int,arg2:Int,fn:(Int,Int)=>Int) {
		println("Doing  initial preparations!!")
		println("Doing some internal calculations!!")
		println(fn(arg1,arg2))
		println("Final calculation is done!!")
		println("======================================")
	}

	def calculate(fn:(Int,Int)=>Int) {
		println("Doing  initial preparations!!")
		println("Doing some internal calculations!!")
		println(fn(12,2))
		println("Final calculation is done!!")
		println("======================================")
	}
}

