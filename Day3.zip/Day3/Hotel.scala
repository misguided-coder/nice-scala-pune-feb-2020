object Hotel {
	
	val name:String = "Radisson Blu"
	val location:String = "MG Road, Pune"
	
	def info() {
		println(s"Name : $name")
		println(s"Location : $location")
		println("==============================")
	}
}

