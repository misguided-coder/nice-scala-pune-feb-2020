trait A {
	def hi

	def hello() :Unit = {
		println("Hello....")
	}
}

trait  B {
	var author = "Rohan"
}

trait C extends B {
	var version:String 
}

abstract class SuperSimple  {

}

class Simple extends SuperSimple with A with C {
	def hi () {
		println("Hi....")
	}

	var version:String = {
		"Version is 1.0.0"
	}
}

object TraitDemo {

	def main(args: Array[String]):Unit = {
		UC1
		//UC2
		//UC3
		//UC4
	}

	def UC1():Unit = {
		
	}
}
