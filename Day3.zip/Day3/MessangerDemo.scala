sealed class Messanger

class SMSMessanger(message:String) extends Messanger {

	def send() {
		println(s"SMS is sent with ----- $message")
	}
}

class WhatsAppMessanger(message:String) extends Messanger {

	def send() {
		println(s"WhatsApp message is sent with ----- $message")
	}
}

class EmailMessanger(message:String) extends Messanger {

	def send() {
		println(s"Email is sent with ----- $message")
	}
}

object MessangerDemo {

	def main(args: Array[String]):Unit = {
	}
}
