object CarDemo {

	def main(args: Array[String]):Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		//UC5
		UC6
	}

	def UC6():Unit = {
		val car1 = new Car(100,"XE","Jaguar",360)
		val car2 = new Car(101,"XF","Jaguar")
		val car3 = new Car(102,"XF")
		val car4 = new Car(101)
		val car5 = new Car()
		
		car1.info
		car2.info
		car3.info
		car4.info
		car5.info
	}

	def UC5():Unit = {
		val car = new Car(100,"XE","Jaguar",360)
		println(car.vin)		
	}

	def UC4():Unit = {
		val car1 = new Car(100,"XE","Jaguar",360)		
		val car2 = new Car(101,"XF","Jaguar",320)

		car1.info
		car2.info
	}




	def UC3():Unit = {
		val car1 = new Car()		
		val car2 = new Car

		/*car1.vin = 1
		car1.model = "A5"
		car1.speed = 70
		car1.make = "Audi"

		car2.vin = 2
		car2.model = "A2"
		car2.speed = 50
		car2.make = "Audi"*/
	
		car1.info
		car2.info
	}


	def UC2():Unit = {
		val car1 = new Car()		
		val car2 = new Car

		car1.vin = 1
		car1.model = "A5"
		car1.speed = 70
		car1.make = "Audi"

		car2.vin = 2
		car2.model = "A2"
		car2.speed = 50
		car2.make = "Audi"
				

		println(car1.vin)
		println(car1.model)
		println(car1.speed)
		println(car1.make)

		println(car2.vin)
		println(car2.model)
		println(car2.speed)
		println(car2.make)
	}


	def UC1():Unit = {
		val car = new Car()		
		println(car)
		println(car.vin)
		println(car.model)
		println(car.make)
	
		car.model = "X6"
			
		println(car.model)

		car.start()
		car.accelerate()
		car.accelerate()
		car.accelerate()
		car.accelerate()
		car.accelerate()

		car.applyBrake()
		car.applyBrake()

		car.stop()

	}
}
