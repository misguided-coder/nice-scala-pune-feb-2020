abstract class Shape(val size:String = "10x8") {
	def draw()

	def info(){
		println("It is all about beautiful shapes!!!")
	}
}

class Circle extends Shape {
	def draw() {
		println("Circle is ready!!!!!")
	}
}

object ShapeDemo {

	def main(args: Array[String]):Unit = {
		UC1
		//UC2
		//UC3
		//UC4
	}

	def UC1():Unit = {
		var shape1:Shape = new Circle
		shape1.info
		shape1.draw
	}
}
