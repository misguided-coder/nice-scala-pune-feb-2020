class Cat {

	private val name:String = "Jugni"
	
	def drink() {
		println(s"Cat ${name} drinks ${Cat.diet} litle milk every day!!")
	}
}

object Cat {
	
	private val diet:Int = 100

	var cat1 = new Cat	

	def show() {
		println(s"Cat name is ${cat1.name}")
	}

}

object CatDemo {
	def main(args: Array[String]):Unit = {
	
		Cat.show 

		var cat2 = new Cat	
		cat2.drink

		println(Cat.diet)
	}	
}

