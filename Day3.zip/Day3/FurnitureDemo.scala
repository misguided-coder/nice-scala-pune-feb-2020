//class Furniture(var material:String = "Wood") { 
class Furniture(val id:Int,val material:String) { 

	println("Inside Furniture primary parametirized constructor!!!!")
	
	def this() {
		this(1,"Wood")
		println("Inside Furniture default constructor!!!!")
	}

	def info() {
		println(s"ID : $id!")
		println(s"Material : $material!")
	}
	
	def make() {
		println(s"Furniture is made of $material!!!!")
	}	
}

class Chair() extends Furniture { 
	println("Inside Chair default constructor!!!!")
}

class Desk() extends Furniture(1,"Iron") { 
	println("Inside Desk default constructor!!!!")
}

class Table(override val material:String,length:Int,width:Int) extends Furniture(2,material) { 
	println("Inside Table default constructor!!!!")

	override def info() {
		super.info
		println(s"Length : $length!")
		println(s"Width : $width!")
	}

	override def make() {
		println(s"Table is made of $material!!!!")
	}	
}

object FurnitureDemo {

	def main(args: Array[String]):Unit = {
		//UC1
		//UC2
		//UC3
		UC4
		//UC5
		//UC6
	}


	def UC4():Unit = {
		var table = new Table("Plastic",12,8)
		table.info
		table.make
	}

	def UC3():Unit = {
		var desk = new Desk()
		desk.make
	}

	def UC2():Unit = {
		var chair = new Chair()
		chair.make
		//println(chair.material)
	}


	def UC1():Unit = {
		//var furniture = new Furniture()
		var furniture = new Furniture(1,"Plastic")

		furniture.make
	}
}
