//callback function 
object FunctionsDemo6 {

	type Display = (String)=>Unit	

	def main(args: Array[String]):Unit = {
		//showName("Jaggu")

		printDetails(showName)
	}
		
	val showName = (name:String) => {
		println(s"Hello Mr. $name, How are you?")
	}


	//def printDetails(fn:(String)=>Unit) {
	def printDetails(fn:Display) {
		println("Loading data from DB!!")
		println("Doing data conversion!!")
		fn("Raj")
		println("Data printing is done!!")
	}
}

