object Main {

	def main(args: Array[String]):Unit = {

		PersonListService.filter((name:String) => name.length() > 8)
		PersonListService.filter((name:String) => name.contains("a"))
		PersonListService.filter((name:String) => name.startsWith("R"))
		PersonListService.filter((name:String) => name.endsWith("u"))
		PersonListService.filter((name:String) => name.endsWith("u") && name.length() > 5)
	}
}
