//Developer B is developing an math application and want to utilize 
//simple calculation API designed by other developer              
object MathCalculator {

	def main(args: Array[String]):Unit = {
		
		val diff = (arg1:Int,arg2:Int) => { arg1 - arg2 }
		
		CalculatorService.calculate(sum)
		CalculatorService.calculate(diff)

		//1. Anonymous functions should be used for small functionality
		//2. Anonymous functions should be used for one time functionality
		//3. Anonymous functions should be used for inline functionality

		//Behavioural Injection		
		CalculatorService.calculate((arg1:Int,arg2:Int) => { arg1 * arg2 })
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 / arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + arg1 + arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + arg1 + arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + arg1 + arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + arg2 + arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + 100 / arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 + 100 * arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 * arg1)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 * arg1 * arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 / arg1 - arg2)
		CalculatorService.calculate((arg1:Int,arg2:Int) => arg1 % arg2)

		CalculatorService.calculate(100,2,(arg1:Int,arg2:Int) => arg1 * arg2)

	}
		
	val sum = (arg1:Int,arg2:Int) => { arg1 + arg2 }
}
