object PersonListService {

	def filter(fn:(String) => Boolean) {
		println("Loading DB driver and other info from environment files!!")
		println("Preparing DB connection!!")
		println("Loading data from DB!!")
		var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
				"Pintu","Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
				"Rose Gulabi", "Laden Humble", "Dawood Raja")
		
		println("Filtered Names ----------- ")

		//Internal iterator
		var idx:Int = 0
		while(idx < names.length) {
			val name = names(idx)	
			if(fn(name)) {
				println(name)	
			}		
			idx = idx + 1			
		}
		println("Data filtering is done!!")
		println("======================================")
	}
}

