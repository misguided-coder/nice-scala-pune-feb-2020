class Car(var vin:Int,var model:String,var make:String,var speed:Int) {

	println("Just working inside primary constructor!!!!")
	println("Making REST API calls from inside primary constructor!!!!")
	
	def this(vin:Int,model:String,make:String) {
		this(vin,model,make,50)
		println("Inside this(vin:Int,model:String,make:String) constructor!!!!")
	}

	def this(vin:Int,model:String) {
		this(vin,model,"Tata")
		println("Inside this(vin:Int,model:String) constructor!!!!")
	}

	def this(vin:Int) {
		this(vin,"Nano")
		println("Inside this(vin:Int) constructor!!!!")
	}

	def this() {
		this(1000)
		println("Inside this() constructor!!!!")
	}
	
	def info() {
		println(s"VIN : $vin")
		println(s"MODEL : ${this.model}")
		println(s"SPEED : $speed")
		println(s"MAKE : $make")
		println("==============================")

	}

	def start() {
		println(s"$make ${this.model} engine is started!!")
	}	

	def accelerate() {
		this.speed = this.speed + 50
		println(s"$make ${this.model} car is running at $speed miles per hr!!")
	}	

	def applyBrake() {
		this.speed = this.speed - 50
		println(s"$make ${this.model} car is running at $speed miles per hr!!")
	}	

	def stop() {
		println(s"$make ${this.model} engine is stopped!!")
	}

	println("REST API calls done from inside primary constructor!!!!")	
	println("Finished calling primary constructor!!!!")	
}

