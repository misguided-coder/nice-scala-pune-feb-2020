//function returning another function
object FunctionsDemo4 {
	def main(args: Array[String]):Unit = {
		var a = hello()
		var b = a()
		b()
		println(a)
		println(a.getClass)
	}

	var hello = () => {
		println("Hello........")

		() => {
			println("Hi........")
			
			() => {
				println("Bye........")
			}
		}
	}

	/*def hello():() => Unit = {
		println("Hello........")

		() => {
			println("Hi........")
		}
	}*/

	/*def hello():() => Unit = {
		println("Hello........")

		return () => {
			println("Hi........")
		}
	}*/

	/*def hello():() => Unit = {
		println("Hello........")

		var hi = () => {
			println("Hi........")
		}
	
		hi
	}*/

	/*def hello():() => Unit = {
		println("Hello........")

		var hi = () => {
			println("Hi........")
		}
	
		return hi
	}*/
}

