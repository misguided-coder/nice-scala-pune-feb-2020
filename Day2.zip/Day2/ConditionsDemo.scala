object ConditionsDemo {
	def main(args: Array[String]): Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		//UC5
		UC6

	}


	def UC6() :Unit =  {

		import java.util.Date
		
		//val data:Any = "Ritesh"
		//val data:Any = 200
		//val data:Any = 23000
		val data:Any = new Date(2010,04,12)

		var rs = data match {

			case "Ritesh" => 
				  "My name is Ritesh Tyagi"
			case "Red"  =>
				  "Red is a sun color"
			case "Yellow"=>
				  "Yellow is an attractive color"
			case data:String =>
				 "String can not be modified"
			case data:Date  =>
				  "data is o type date"
			case 200 =>
				 "Current number is 200"
			case data:Int =>
				 "value is of type int"
			case _ =>
				  "Valuee is unknown"
		}	

		println(rs)	
	}



	def UC5() :Unit =  {
		
		val color = "Blue"

		var rs = color match {

			case "Black" => 
				  "Black is a beautiful color"
			case "Red"  =>
				  "Red is a sun color"
			case "Yellow"=>
				  "Yellow is an attractive color"
			case "White" =>
				 "White  is peaceful color"
			case "Blue"  =>
				  "Blue is a cool color"
			case _ =>
				  "Color is unknown"
		}	

		println(rs)	
	}


	def UC4() :Unit =  {
		
		val color = "Tomato"

		color match {

			case "Black" => 
				  println("Black is a beautiful color")
			case "Red"  =>
				  println("Red is a sun color")
			case "Yellow"=>
				  println("Yellow is an attractive color")
			case "White" =>
				  println("White  is peaceful color")
			case "Blue"  =>
				  println("Blue is a cool color")
			case _ =>
				  println("Color is unknown")
		}		
	}

	//Java Way
	def UC3() :Unit =  {
		val age = 20
		var result = ""

		if(age <= 5) {
			//20 loc
			println("I am showing age.")
			result = "You are too young. You will be lost.!!"
		}else if(age <= 10) {
			println("I am showing details.")
			result = "You are young. Go home!!"
		}else if(age <= 20) {
			println("I am showing more details.")
			result = "You are little grown. Just play!!"
		}else if(age <= 30) {
			println("I am showing details from DB.")
			result = "You are young and can have fun!!"
		}else {
			println("I am showing details from File.")
			result = "You are old now!!"
		}	

		println(result)	
	}


	//Scala Way
	def UC2() :Unit =  {
		val age = 20

		val result = if(age <= 5) {
			//20 loc
			println("I am showing age.")
			"You are too young. You will be lost.!!"
		}else if(age <= 10) {
			println("I am showing details.")
			"You are young. Go home!!"
		}else if(age <= 20) {
			println("I am showing more details.")
			"You are little grown. Just play!!"
		}else if(age <= 30) {
			println("I am showing details from DB.")
			"You are young and can have fun!!"
		}else {
			println("I am showing details from File.")
			"You are old now!!"
		}	

		println(result)	
	}


	def UC1() :Unit =  {
		val age = 10
		if(age <= 5) {
			println("You are too young. You will be lost.!!")
		}else if(age <= 10) {
			println("You are young. Go home!!")
		}else if(age <= 20) {
			println("You are little grown. Just play!!")
		}else if(age <= 30) {
			println("You are young and can have fun!!")
		}else {
			println("You are old now!!")
		}		
	}
}


