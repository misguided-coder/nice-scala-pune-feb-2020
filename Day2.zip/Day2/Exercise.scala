//function currying
object Exercise {
	def main(args: Array[String]):Unit = {
		//UC1
		//UC2
		UC3
	}

	def UC3():Unit = {
		
		val showDelhiWeather = showWeather("Delhi")
		val showPuneWeather = showWeather("Pune")

		showDelhiWeather(10)
		showDelhiWeather(12)
		showDelhiWeather(14)
		showDelhiWeather(18)

		showPuneWeather(10)
		showPuneWeather(20)
	}

	def UC2():Unit = {
		showWeather("Delhi")(10)
		showWeather("Delhi")(12)
		showWeather("Delhi")(15)
		showWeather("Delhi")(20)
	}

	var showWeather = (city:String) => {
		(day:Int) => {
			println(s"Weather in $city on $day day is ${Math.floor(Math.random()*40)} degree!!")
		}
	}

	def UC1():Unit = {

		displayWeather("Pune",10)
		displayWeather("Pune",12)
		displayWeather("Pune",15)
		displayWeather("Pune",25)
		displayWeather("Pune",28)
	}


	var displayWeather = (city:String,day:Int) => {
		println(s"Weather in $city on $day day is ${Math.floor(Math.random()*40)} degree!!")
	}

}

