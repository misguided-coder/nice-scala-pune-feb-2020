object DataTypeDemo {
	def main(args: Array[String]): Unit = {
	
		var data:Any = 100
		println(data)
		println(data.getClass)
		data = 100.00
		println(data)
		println(data.getClass)
		data = 'T'
		println(data)
		println(data.getClass)
		data = new java.util.Date()
		println(data)
		println(data.getClass)

		
	}
}


