//callback function 
object FunctionsDemo6 {
	def main(args: Array[String]):Unit = {
		//showName("Jaggu")

		printDetails(showName)
	}
		
	val showName = (name:String) => {
		println(s"Hello Mr. $name, How are you?")
	}


	def printDetails(fn:(String)=>Unit) {
		println("Loading data from DB!!")
		println("Doing data conversion!!")
		fn("Raj")
		println("Data printing is done!!")
	}
}

