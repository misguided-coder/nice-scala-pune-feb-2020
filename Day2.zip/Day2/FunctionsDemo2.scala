object FunctionsDemo2 {
	def main(args: Array[String]):Unit = {

		var i =10
		var j = i


		hello()
		a()
		println(a)
		println(a.getClass)

		b("Raj",12)

		val rs = db
		
		println(rs)
	
		db()
		rs()

		println(sqrt(10))

	}

	//anonymous function syntex
	//(args) => { body }

	var sqrt = (number:Int) => number * number		

	var db = () => 24000.00

	//var db = () => { 24000.00}

	/*var db = () => {
		println("Calling DB....")
		24000.00
	}*/
	

	var b = (name:String,age:Int) =>  println(s"Hi $name and Age is $age........") 

	//var b = (name:String,age:Int) => { println(s"Hi $name and Age is $age........") }

	/*var b = (name:String,age:Int) => {
		println(s"Hi $name and Age is $age........")
	}*/


	//function expression
	var a = () => {
		println("Hi........")
	}

	//function declaration
	def hello() {
		println("Hello........")
	}
}



