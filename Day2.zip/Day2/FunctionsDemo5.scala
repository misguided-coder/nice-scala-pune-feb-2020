//function currying
object FunctionsDemo5 {
	def main(args: Array[String]):Unit = {
		//UC1
		UC2
	}

	def UC2():Unit = {

		var rs = grow()()()()(20)
		//100 loc
		rs(25)(40)()
	}

	def UC1():Unit = {

		val young = grow()
		//50 loc
		val younger = young()
		//200 loc
		younger()
	}


	var grow = () => {
		println("I am new born infant!!")

		() => {
			println("I am little grown!!")
			
			() => {
				println("I can now walk!!")
				() => {	
					println("I am little younger!!")
					(age:Int) => {	
						println(s"I am $age yrs old and can run!!")
		
						(age:Int) => {	
							println(s"I am $age yrs old and strong enough to fight!")
							(age:Int) => {	
								println(s"I am $age yrs old and strong ready to kill!!")
								() => {	
									println(s"I am little old!!")
								}
							}
						}
					}
				}
			}
		}
	}

}

