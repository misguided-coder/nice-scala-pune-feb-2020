object StringTemplateDemo {
	def main(args: Array[String]): Unit = {

		val age = 12
		val city = "Pune"
		val phone = 981000000
		
		var str1 = "I am "+age+" yr old. I live in "+city+" and my phone number is "+phone
		println(str1)

		var str2 = s"I am ${age} yr old. I live in $city and my phone number is $phone and result is ${2+2} and random number is ${Math.random()}"
		println(str2)
	}

}



