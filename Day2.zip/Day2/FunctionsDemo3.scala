//function nesting demo
object FunctionsDemo3 {
	def main(args: Array[String]):Unit = {
		hello()
		greet()
	}

	def greet() {
		println("GM........")

		var hi = () => {
			println("GN........")

			var bye = () => {
				println("GAN........")
			}
			bye()
		}
	
		hi()
	}

	def hello() {
		println("Hello........")

		def hi() {
			println("Hi........")

			def bye() {
				println("Bye........")
			}
			bye()
		}
	
		hi()
	}
}



