object FunctionsDemo1 {
	def main(args: Array[String]):Unit = {

		/*hello()
		hello

		hi		
	
		greet("Raj")
	
		bye("Jaggu",20) //passing arguments by position
		bye(name = "Jaggu",age = 20) //passing arguments by name
		bye(age = 20,name = "Jaggu") //passing arguments by name
		bye("Jaggu") 
		bye() 
		bye(age = 20) //passing arguments by name

		sum(10,10)
		sum(5) //function invocation with optional arguments
		sum() //function invocation with optional arguments
		*/

		println(sqrt())
		println(sqrt)
		println(sqrt.getClass)

		//val rs = sqrt()
		val rs = sqrt

		println(rs)
		println(rs.getClass)
	}

	//var sqrt:Int = 2 * 2 

	//def sqrt():Int = 2 * 2 

	//def sqrt():Int = { 2 * 2 }

	/*def sqrt():Int = {
		println("Doing some calculations......")
		2 * 2	
	}*/

	/*def sqrt():Int = {
		println("Doing some calculations......")
		return 2 * 2	
	}*/

	def sqrt() = println("Doing some calculations......")
	
	/*def sqrt():Unit = {
		println("Doing some calculations......")
		return 2 * 2	
	}*/

	//function declaration with default arguments
	def sum(arg1:Int = 2,arg2:Int = 2) {
		println(s"SUM : ${arg1+arg2}!!")
	}

	/*def sum(arg1:Int,arg2:Int) {
		println(s"SUM : ${arg1+arg2}!!")
	}*/

	def bye(name:String = "Rohan",age:Int = 10) {
		println(s"Bye Mr $name and You are $age yrs old!!")
	}

	/*def bye(name:String,age:Int) {
		println(s"Bye Mr $name and You are $age yrs old!!")
	}*/

	def greet(name:String) {
		println(s"GM $name!!")
	}

	def hi {
		println("Hi........")
	}

	def hello() {
		println("Hello........")
	}
}



