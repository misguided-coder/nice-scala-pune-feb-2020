object Hello {
	def main(args: Array[String]): Unit = {
		println("Welcome to Scalabale Language!!");
	}
}
