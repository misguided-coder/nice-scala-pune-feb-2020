object DataTypeDemo2 {
	def main(args: Array[String]): Unit = {

		//immmutable data
		var age = 10 //data type inference
		println(age)
		age = 12
		println(age)
		
		//mutable value
		val i = 100 //data type inference
		println(i)
				
		//i = 200 //will not work
		//println(i)

	}
}


