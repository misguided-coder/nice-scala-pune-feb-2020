object HelloWorld {
	def main(args: Array[String]): Unit = {
		println("Welcome to Scalabale Language and Easy to use!!")
	}
}
