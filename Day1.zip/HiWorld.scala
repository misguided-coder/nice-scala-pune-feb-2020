def hi(): Unit = {
	println("Hi All!!")
}

hi();
hi()
hi