object ArrayDemo {
	def main(args: Array[String]): Unit = {
		//UC1()
		//UC2
		//UC3
		//UC4
		//UC5
		//UC6
		//UC7
		//UC8
		//UC9
		UC10
	}

	def UC10() :Unit =  {
		
		var numbers = Array(Array(1,2,3),Array(4,5,6),Array(7,8,9),Array(10,11,12))
	
		println(numbers(0)(0))
		println(numbers(0)(1))
		println(numbers(0)(2))


		println(numbers(1))
		println(numbers(2))
		println(numbers(3))

	}

	def UC9() :Unit =  {
		
		var numbers = Array.ofDim[Int](4,2)
		
		numbers(0)(0) = 11
		numbers(0)(1) = 12

		numbers(1)(0) = 21
		numbers(1)(1) = 22

		
		println(numbers(0)(0))
		println(numbers(0)(1))

		println(numbers(1)(0))
		println(numbers(1)(1))

		println(numbers(2)(0))
		println(numbers(2)(1))

		println(numbers(3)(0))
		println(numbers(3)(1))

	}

	def UC8() :Unit =  {
		
		var numbers = Array.ofDim[Int](2)
		println(numbers(0))
		println(numbers(1))
	}


	def UC7() :Unit =  {
		
		var numbers:Array[Array[Int]] = new Array[Array[Int]](4)
		numbers(0) = new Array[Int](2)	
		numbers(1) = new Array[Int](2)	
		numbers(2) = new Array[Int](4)	
		numbers(3) = new Array[Int](2)	

		numbers(0)(0) = 11
		numbers(0)(1) = 12

		numbers(1)(0) = 21
		numbers(1)(1) = 22

		
		println(numbers(0)(0))
		println(numbers(0)(1))

		println(numbers(1)(0))
		println(numbers(1)(1))

		println(numbers(2)(0))
		println(numbers(2)(1))

		println(numbers(3)(0))
		println(numbers(3)(1))
	}

	def UC6() :Unit =  {
		
		//array declaration and initialization plus population
		var numbers = Array(34,656,12,78,34,12,76,34,22,55,88,34)

		println("Length "+numbers.length)  
		println(numbers) 
		println(numbers.getClass) 
		println(numbers.isInstanceOf[Array[Int]]) 
 
		println(numbers(0))  
  		println(numbers(3))
  		println(numbers(8))
	}


	def UC5() :Unit =  {
		
		//array declaration 
		//var numbers = new Array(4)
		var numbers = new Array[Int](4)

		//array population
		numbers(0) = 1000
		numbers(1) = 2000
		numbers(2) = 3000
		numbers(3) = 4000
	
		println(numbers)

		//accessing array members
		println(numbers(0)) //UAP - Unified Access Pattern 
  		println(numbers(3))
	}

	def UC4() :Unit =  {
		
		//array declaration 
		//var numbers = new Array(4)
		var numbers = new Array[Int](4)

		println(numbers)
		println(numbers(0))
		println(numbers(3))
	}



	def UC3() :Unit =  {
		
		//array declaration 
		var numbers:Array[Int] = new Array(4)

		println(numbers)
	}

	def UC2() :Unit =  {
		
		//array declaration 
		var numbers:Array[Int] = null

		//array initialization
		numbers = new Array[Int](4)

		println(numbers)
	}

	def UC1() :Unit =  {
		//array declaration & initialization
		var numbers:Array[Int] = new Array[Int](4)
		println(numbers)
	}
}


