object DataTypeDemo1 {
	def main(args: Array[String]): Unit = {
		
		var age:Int = 24; //explicit data type declaration 
		println(age)
		println(age.getClass())
		println(age.getClass)
		println(age.isInstanceOf[Int])


		var i = 100 //data type inference
		println(i)
		println(i.getClass())

		//var name = "Rohan" //data type inference
		var name:String = "Rohan" 
		println(name)
		println(name.getClass())

		//var letter = 'T' //data type inference
		var letter:Char = 'T' 
		println(letter)
		println(letter.getClass())

		//var status = true  //data type inference
		var status:Boolean = true  
		println(status)
		println(status.getClass())

		//var balance = 450000.00  //data type inference
		var balance:Double = 450000.00 
		println(balance)
		println(balance.getClass())

		var a = 2000 //data type inference
		println(a)
		println(a.getClass())

		//will not work
		//a = 2000.00 //data type inference
	
	}
}


